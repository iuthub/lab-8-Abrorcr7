@extends('layouts.master')
@section('content')
    <p>This is my body content.</p>
@stop
  
